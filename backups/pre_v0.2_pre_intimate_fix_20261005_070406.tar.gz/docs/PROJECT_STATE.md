# PROJECT_STATE · 小满树洞（Xiaoman Treehole）

> 本文档是项目的**唯一权威状态源**，持续更新。任何人（或 AI）接手项目，先完整读完本文件即可掌握全局。
> 最后更新：2026-10-04 22:00 ｜ 当前版本：v0.1.0-alpha（骨架期） ｜ 状态：环境检查中

---

## 0. 项目一句话

安卓端 AI 树洞/倾听陪伴应用「小满树洞」：Live2D 萌系角色 + 活人感对话 + 语音回复，角色名"小满"（26岁新媒体运营，养橘猫团子）。

## 1. 硬性需求清单（来自用户，验收标准）

| # | 需求 | 验收方式 | 状态 |
|---|------|---------|------|
| R1 | 安卓全面跑通（需模拟器验证） | APK 可安装/模拟器或降级方案截图 | ⏳ |
| R2 | 文字聊天 | 对话流程测试 | ⏳ |
| R3 | 语音回复且确认语音正常 | TTS→ASR 回环验证 | ⏳ |
| R4 | UI 极其出色：温馨、萌系、清爽、二次元手绘感、灵动 | Playwright 截图人工审查≥2轮迭代 | ⏳ |
| R5 | Live2D 模型结构化手术 + 实时交互 | 模型 JSON 改造记录 + 表情/动作/口型联动 | ⏳ |
| R6 | 活人感聊天，用户能长久聊下去 | 分条发送/打字延迟/主动开口/留存钩子/记忆 | ⏳ |
| R7 | 最大复用 GitHub 开源项目 | 复用清单（见 §6） | ⏳ |
| R8 | 暂无 API：Mock 充当，明天换真 API | 单一 LLM 适配器接口，一行切换 | ⏳ |
| R9 | 最终产品开源 | MIT LICENSE + 素材出处登记 | ⏳ |
| R10 | 用户视角分析 + 持续迭代 | 分析报告 + 迭代清单 | ⏳ |

## 2. 关键约束（用户明示）

1. **活文档**：每步操作、每次代码变更都要记录进 DEVLOG.md；本文档不断更新，保证随时可交接。
2. **备份先行**：每次重大代码变更前，先做备份（scripts/backup.sh，产物进 backups/）。
3. 全程自主决策，不问用户；任务完成前不停。
4. 沙箱资源有限（无 GPU，内存紧张），所有重活走"后台+轮询"。

## 3. 架构（当前设计）

```
┌─────────────── Android APK（WebView 壳，待定 Capacitor/原生） ───────────────┐
│                                                                             │
│  web/ 前端核心（同一份代码，浏览器=我们的"模拟器"）                            │
│  ├─ index.html        萌系 UI：Live2D 舞台(上) + 聊天流(下) + 输入栏          │
│  ├─ js/live2d.js      PixiJS + pixi-live2d-display；情绪→表情/动作；口型同步  │
│  ├─ js/app.js         活人感引擎：分条发送/打字延迟/主动开口/记忆/留存钩子     │
│  ├─ js/api.js         LLM 适配器：MOCK ⇄ OPENAI 兼容（真 API 明天接入）       │
│  └─ js/tts.js         TTS 适配器：服务端 TTS(mp3) / 浏览器 speechSynthesis    │
│                                                                             │
│  server/（本地/局域网跑，安卓壳内也可打包）                                    │
│  ├─ mock_api.py       我充当的 API：情绪识别+回复模板+记忆+结构化输出          │
│  └─ tts_server.py     edge-tts 封装（免费，中文自然）                          │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 结构化 API 契约（明天接真 API 就按这个来）

请求：`POST /v1/chat/completions`，OpenAI 兼容字段。
响应 `choices[0].message.content` 必须是 JSON 字符串：

```json
{
  "reply": "回复正文（可以含「|」表示建议分条）",
  "emotion": "happy|comfort|sad|surprised|neutral|worried",
  "motion": "idle|tap|shake|greeting",
  "tts": true,
  "memory_write": {"key": "值"},
  "hook": "留存钩子可选文案，为空则无"
}
```

安全层（危机干预）在前端+Mock API 双侧实现，不依赖大模型自觉：
触发词命中 → 固定温暖话术 + 全国心理援助热线 **12356** + Live2D 切 worried 表情。

## 4. 目录结构

```
treehole-app/
├─ PROJECT_STATE.md      ← 本文件
├─ docs/                 ← DEVLOG.md（操作日志）、设计稿、用户视角分析
├─ backups/              ← 重大变更前的快照 tar
├─ scripts/              ← backup.sh 等工具脚本
├─ web/                  ← 前端核心（index.html + css/ + js/ + assets/）
├─ server/               ← mock_api.py + tts_server.py
└─ android/              ← 安卓壳工程（阶段二）
```

## 5. 环境事实（持续补充）

- 沙箱：无 GPU、内存约 4GB、网络可用（npm/pip/curl 已验证可用）
- 已有：Node 24、Python3、Playwright（Chromium）、z-ai SDK
- 待确认：/dev/kvm（决定模拟器可行性）、Java（决定 Gradle 打包）、磁盘余量

## 6. 复用清单（R7，持续登记）

| 来源 | 用途 | 许可 |
|------|------|------|
| pixi-live2d-display (guansss) | Live2D 渲染 | MIT |
| PixiJS | 渲染底层 | MIT |
| Live2D 官方免费示例模型 | 角色模型（将做结构化改造） | Live2D 免费素材许可 |
| edge-tts | 免费 TTS | GPL-3.0（仅本地服务调用，不打包进闭源分发；本项目本身开源故兼容） |
| Open-LLM-VTuber (t41372) | 架构参考：情绪标签驱动 Live2D | AGPL-3.0（仅参考思路，不复代码） |
| 前几日"小满"测试集与盲测结论 | 人设、活人感规则、安全层话术 | 自产 |

## 7. 测试记录

（截图与验证结果写入时在此登记）

## 8. 已知问题 / 风险

- 沙箱无 KVM 的话，Android 模拟器将极慢甚至不可行 → 降级方案：APK 构建 + Chromium 移动视口仿真截图 + 交付用户真机安装
- Gradle/SDK 下载量大，内存紧张时用 --no-daemon + 限制 JVM 堆

## 9. 交接指南（给下一个接手者）

1. 读 §1 需求与 §2 约束 → 2. 读 docs/DEVLOG.md 最新 20 条 → 3. 跑 `python3 server/mock_api.py &` + `python3 server/tts_server.py &` → 4. 浏览器打开 web/index.html 即可看全部效果 → 5. 明日接真 API：只改 js/api.js 的 BASE_URL 与密钥。
